<?php
  require_once "../vars/var_manip.php";
  $locz = (PHP_OS == "Linux" ? 
  "/etc/openvpn/script" : "../vars");
  $DB_Auth = get_varx("$locz/config.sh");
  mysql_connect($DB_Auth['HOST'],$DB_Auth['USER'],$DB_Auth['PASS']) or die(mysql_error());
	mysql_select_db($DB_Auth['DB']) or die("Cannot connect to the database.");
  function show_records(){
      $query = mysql_fetch_array(mysql_query(
        "
          select 
            sum(log_send <> 0) as conns,
            sum(log_send) as received
            from log"));
      $query['conns'] = $query['conns'] == '' ? "0" : $query['conns'];
      return $query;
  }
  function show_stats(){
      // BTYES RECEIVED
      Print get_byte_text("", show_records()['received']).
      // CONNECTIONS
      "/" . show_records()['conns'];
  }
  function load_table_stats(){
      $queryx = mysql_query(
        "
          select distinct
            user_id as id
            from log");
      $cc = 1;
      while ($hh = mysql_fetch_array($queryx)) {
            $stat = get_user_stats($hh['id']);
            Print 
            '<tr>
              <td id="numx">' . $cc++ . '</td>
              <td id="left">' . $hh['id'] . ($stat['o'] ? "(on)" : "(off)") . '</td>
              <td>' . get_byte_text('',$stat['s']) . '</td>
              <td>' . get_byte_text('', $stat['r']) . '</td>
            </tr>';
      }
  }
  function get_user_stats($id){
    $bytes_r = mysql_fetch_array(mysql_query(
              "select
              sum(log_received) as received,
              sum(log_send) as sent
              from log where user_id='". $id . "'"));
	$active = mysql_fetch_array(mysql_query(
	"select user_online as o from user where user_id='". $id . "'"))['o'];
    return array('s' => $bytes_r['received'], 'r' => $bytes_r['sent'],'o' => $active);
  }
  // FUNCTIONS
  function write($txt){
    print($txt . "<br>");
  }
  function get_byte_text($txt='',$bytes){
    $arrt = array(0,1,2,3,4);
    $arrg = array("B","KB","MB","GB","TB");
    foreach ($arrt as $gg) {
      if(round($bytes/pow(1024, $gg),2) < 1024)
        {
          return $txt . round($bytes/pow(1024, $gg),2) . " " . $arrg[$gg];
        }
      }
    }
?>