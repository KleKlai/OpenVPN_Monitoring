<?php require "stats.php";?>
<html>
   <head>
      <meta name="viewport" content="width=device-width">
     	<link rel="stylesheet" type="text/css" href="/styles/styles.css">
     	<title>Monitoring System</title>
		<script type="text/javascript" src="/styles/jquery-3.3.1.js"></script>
   </head>
   <body>
		<div id="blue"></a></div>
		<div id="contents">
      <a href="/home/"><img src="Sun_Cellular.png" alt="Sun Cellular Logo" style="width:230px;height:200px;"></a>
			<table align="center">
				<h2>OPENVPN SERVER STATISTICS</h2>
 				<tr>
					<th id="numx">ID</th>
					<th id="usr">User</th>
					<th>Inbound</th>
					<th>Outbound</th>
				</tr>
      		<?php load_table_stats(); ?>
			</table>
			<div id="foot">Total Usage: <?php show_stats();?><br/>
         <a href="/download/">Configuration File</a>
      </div>
		</div>
		<span id="txt">KleKlai</span>
		<span id="creator">UDPTEAM</span>
  	</body>
   <script type="text/javascript" src="/styles/scripts.js"></script>
</html>