<html>
   <head>
      <meta name="viewport" content="width=device-width">
     	<link rel="stylesheet" type="text/css" href="styles.css">
     	<title>X-DCB (Monitoring)</title>
		<script type="text/javascript" src="/styles/jquery-3.3.1.js"></script>
   </head>
<body>
    <div>
        <div>Client Config Download</div>
        <input type="password"
               placeholder="Password">
        <button>Download Config</button>
    </div>
</body>
    <script type="text/javascript" src="scripts.js"></script>
</html>