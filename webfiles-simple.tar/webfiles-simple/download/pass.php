<?php
   require_once '../vars/var_manip.php';
   $locz = (PHP_OS == "Linux" ? 
   "/etc/openvpn/script" : "../vars");
   $cpass = get_varx("$locz/config.sh");
   if($_POST['pass'] == $cpass['CPASS'] && $_SERVER['REQUEST_METHOD'] == 'POST'){
    	$ipx = $_SERVER['HTTP_HOST'];
      $client = preg_replace(
         "/xxxx/",
         $ipx,
         file_get_contents("$locz/client.ovpn"));
      echo json_encode([
         'p'=>true,
         'b'=>"Downloading...",
         'f'=>sprintf("client-%u.ovpn",explode('.', $ipx)[3]),
         'c'=>"data:application/octet-stream;base64,". base64_encode($client)]);
   } else {
      echo json_encode([
         'p'=>false,
         'b'=>"Wrong password."]);
   }
?>