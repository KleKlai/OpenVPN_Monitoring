var main = $("#blue");
var texx = $("#txt");
var texc = $("#creator");
var hdr = $("#tbox");
var cnt = $("#contents");
var maxw = parseInt(main.css("max-width"));
var maxt = parseInt(texx.css("max-width"));
var maxx = $(window).width();
var minxy = 10;
var leftmax = (maxx/2) - (maxw/2);
var leftmaxt = (maxx/2) - (maxt/2);
var topmax = parseInt($("#max").css("top"));
var minf = 22;
$(window).scroll(function() {
	var srl = $(window).scrollTop();
	var rato = ratio(srl,maxw,0,100);
	var nrat = 100;
	var rat = ratio(srl,maxw,80);
	var rt = ratio(srl,maxw,50);
	main.css({
		"width" : maxw * rato, 
		"height" : maxw * rato,
		"left" : nval(leftmax * rato, minxy),
		"top" : nval(100 * rato, minxy)
	});
	//main.text(rato);
	texx.css({
		"font-size" : nval(35 * rato, minf),
		"top" : nval(450 * rato, 0),
		"left" : nval(leftmaxt * rato, 55 * (1-rato)),
		"width" : maxx * rato,
		"padding-top" : 12 * (1-rato)
	});
	texc.css({
		"top" : nval(430 * rato, 20),
		"left" : nval(leftmaxt * rato, 55 * (1-rato)),
		"width" : maxx * rato,
		"padding-top" : 12 * (1-rato)
	});
	hdr.css({
		"opacity" : rat == 0 ? 1 : 1-rat
	});
	cnt.css({
		"opacity" : rato == 0 ? 1 : 1-rato
	});
})

function ratio(delta, max, sub = 0, subx = 0){
	var newr = 1-(delta - sub < max - subx ? (delta - sub)/(max - subx) : 1);
	return newr < 1 ? newr : 1;
}
function nval(cval, minval, extra = 0,gmax = 0){
	return cval > minval + extra ? cval : (gmax == 1 ? 0 : minval + extra);
}