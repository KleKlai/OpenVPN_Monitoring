<?php
    header("location:home")
?>