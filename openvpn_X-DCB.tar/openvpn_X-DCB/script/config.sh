#!/bin/bash
##Dababase Server
#Username
USER='root'
#Password
PASS=''
#database name
DB='openvpn'
HOST='localhost'
